@extends('layouts.master')
@section('title', 'Test Page')
@section('content')
<p>Hello</p>
@endsection